import React from 'react'

export default function
    () {
    return (
        <div>
            <div className="container-fluid">
                <div className="row bg-dark text-white text-center">
                    <div className="col">
                        <h1 className="display-4 p-2">Feedback Form</h1>
                    </div>
                </div>
            </div>

            <div className="container-fluid my-3">
                <div className="row">
                    <div className="col-lg-6 offset-lg-3">
                        <h2 className="text-center text-muted fw-lighter my-3"><i>Over the last two weeks</i></h2>
                    </div>
                </div>
            </div>
        </div>
    )
}
