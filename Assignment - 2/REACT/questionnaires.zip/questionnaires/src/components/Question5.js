import React from 'react'
import QuestionHeader from './QuestionHeader'

const Question1 = (props) => {
  const q = props.title

  return (
    <div>
      <QuestionHeader />
      <div className="container">
        <div className="row">
          <div className="col-lg-6 offset-lg-3">
            <div className="card border-0 shadow-lg">
              <div className="card-body m-4">
                <h1 className=" py-2 fs-4">{q[4].question}</h1>

                {q[0].options.map((object, i) => {
                  return <div className="text-secondary">

                    <div className="form-check">
                      <input className="form-check-input" type="radio" name="answer5" value={q[4].options[i]} />
                      <label className="form-check-label" for="answer5">{q[0].options[i].response}</label>
                    </div>

                  </div>
                })}
                <div className="mt-4 text-center d-grid gap-2 d-md-flex justify-content-md-end">
                  {/* <a href="" className="btn btn-outline-primary rounded-pill" role="button">Previous</a> */}
                  <a href="Question2.html" className="btn btn-primary rounded-pill px-4" role="button">Next</a>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>

  )
}

export default Question1