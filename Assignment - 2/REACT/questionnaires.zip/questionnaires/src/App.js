import Question1 from "./components/Question1";
import questions from './questions.json'

function App() {
  const q = questions
  return (
    <div className="App">
      <Question1 title={q}/>
    </div>
  );
}

export default App;
